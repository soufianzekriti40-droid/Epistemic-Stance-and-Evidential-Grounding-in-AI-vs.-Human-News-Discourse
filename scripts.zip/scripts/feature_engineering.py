"""
Discourse Project: Feature Engineering & Extraction Pipeline
Extracts discourse-pragmatic features (epistemic stance and evidentiality) 
using token-level constraints and spaCy dependency parsing.

The core linguistic extraction framework and pipeline logic were originally 
designed and written by the author, with AI utilized for minor adjustments, 
code optimization, and path refinements.
"""
import json
import os
import re
from datetime import datetime
from pathlib import Path
import pandas as pd
import spacy

# Load spaCy pipeline for structural dependency checks
nlp = spacy.load("en_core_web_sm")

# ---------------------------------------------------------------------------
# Linguistic Lexicons & Structural Markers
# ---------------------------------------------------------------------------

# Epistemic stance lemmas with low pragmatic ambiguity
LEMMATIC_HEDGES = {
    "possibly", "perhaps", "likely", "unlikely", "apparently", "reportedly",
    "indicate", "estimate", "roughly", "approximately", "potentially", 
    "presumably", "allegedly", "purportedly", "ostensibly", "arguably", "seem"
}

# Hyland (2005) boosters signaling high stance certainty
BOOSTERS = {
    "clearly", "obviously", "certainly", "definitely", "undoubtedly", 
    "confirm", "prove", "demonstrate", "evident", "known", "assert", 
    "insist", "stress", "emphasise", "emphasize", "highlight"
}

# Pre-defined structural attribution chunks
FIXED_ATTRIBUTIONS = [
    "according to", "said in a statement", "told reporters", "told journalists",
    "has not been independently verified", "could not be independently confirmed",
    "it remains unclear", "it is not clear", "it is unclear", "it is believed", 
    "it was reported", "it is alleged"
]

# Targeted reporting verbs for subject-anchored dependency extraction
REPORTING_LEMMAS = {"say", "tell", "add", "report", "state"}

# Targeted epistemic modals
MODAL_LEMMAS = {"could", "may", "might", "would"}

# ---------------------------------------------------------------------------
# Feature Extraction Engine
# ---------------------------------------------------------------------------

def process_text(raw_text, file_name, folder_label, article_id, headline):
    """Parses text data and maps structural frequencies via dependency parsing."""
    doc = nlp(raw_text)

    # Base token arrays
    words          = [t for t in doc if not t.is_punct and not t.is_space]
    word_count     = len(words)
    sentence_count = len(list(doc.sents))
    text_lower     = raw_text.lower()

    # 1. Base Lexical Feature Audits
    base_hedge_count = sum(1 for t in words if t.lemma_.lower() in LEMMATIC_HEDGES)
    booster_raw      = sum(1 for t in words if t.lemma_.lower() in BOOSTERS)

    # 2. Context-Filtered Hedges (Grammatical Verification)
    modal_aux_hedge_raw        = 0
    existential_aux_hedge_raw  = 0
    structural_frame_hedge_raw = 0

    for i, token in enumerate(doc):
        # Verify modals function strictly as auxiliary verb operators
        if token.lemma_.lower() in MODAL_LEMMAS and token.pos_ == "AUX":
            modal_aux_hedge_raw += 1
            
            # Catch existential uncertainty markers ("could be", "may be")
            if i + 1 < len(doc) and doc[i+1].lemma_.lower() == "be":
                existential_aux_hedge_raw += 1
        
        # Enforce structural syntax constraints on ambiguous stance verbs
        if token.lemma_.lower() == "appear":
            if i + 2 < len(doc) and doc[i+1].lemma_.lower() == "to" and doc[i+2].pos_ in ("VERB", "AUX"):
                structural_frame_hedge_raw += 1
                
        elif token.lemma_.lower() == "suggest":
            if i + 1 < len(doc) and doc[i+1].lemma_.lower() == "that":
                structural_frame_hedge_raw += 1

    # Aggregate total verified hedges
    hedge_raw = base_hedge_count + modal_aux_hedge_raw + structural_frame_hedge_raw

    # 3. Sourced & Subject-Anchored Attribution Matching
    fixed_attr_count = sum(len(re.findall(re.escape(p), text_lower)) for p in FIXED_ATTRIBUTIONS)
    anchored_attr_count = 0
    
    for token in doc:
        if token.lemma_.lower() in REPORTING_LEMMAS:
            # Check dependency tree for nominal subject parameters (nsubj / nsubjpass)
            has_subject = any(child.dep_ in ("nsubj", "nsubjpass") for child in token.children)
            if has_subject:
                anchored_attr_count += 1
                
    attribution_raw = fixed_attr_count + anchored_attr_count

    # 4. Syntactic Control Mapping: Passive Voice
    passive_raw = sum(1 for t in doc if t.dep_ in ("auxpass", "nsubjpass"))

    # 5. Named Entity Tracking
    entity_raw = len(doc.ents)

    # Metric normalization helper
    def per_1k(n):
        return round((n / word_count) * 1000, 3) if word_count > 0 else 0.0

    return {
        # Meta Fields
        "article_id":  article_id,
        "label":       folder_label,
        "source_file": file_name,
        "headline":    headline,

        # Normalized Variations (Per 1k tokens)
        "hedge_per_1k":               per_1k(hedge_raw),
        "booster_per_1k":             per_1k(booster_raw),
        "attribution_per_1k":         per_1k(attribution_raw),
        "passive_per_1k":             per_1k(passive_raw),
        "entity_per_1k":              per_1k(entity_raw),
        "existential_hedge_per_1k":   per_1k(existential_aux_hedge_raw),

        # Raw Variables
        "word_count":                 word_count,
        "sentence_count":             sentence_count,
        "hedge_raw":                  hedge_raw,
        "booster_raw":                booster_raw,
        "attribution_raw":            attribution_raw,
        "passive_raw":                passive_raw,
        "entity_raw":                 entity_raw,
        "existential_hedge_raw":      existential_aux_hedge_raw
    }

# ----------
# Pipeline Execution Setup


script_location = Path(__file__).resolve()
corpus_path     = script_location.parent.parent / "data" / "cleaned"
results_path    = script_location.parent.parent / "results"
os.makedirs(results_path, exist_ok=True)

# Point folders precisely to the outputs of the cleaning pipeline script
folders_path = ["human_corpus", "ai_corpus"]
results      = []
test_limit   = None  # Set an integer limit here to run micro-tests if needed

for folder in folders_path:
    target_path  = corpus_path / folder
    folder_label = "human" if "human" in folder else "ai"

    if not target_path.exists():
        print(f"[WARNING] Input path missing, skipping: {target_path}")
        continue

    print(f"[INFO] Reading records from: {target_path}")
    processed_count = 0

    for file_path in target_path.rglob("*.json"):
        if test_limit is not None and processed_count >= test_limit:
            break

        try:
            with open(file_path, "r", encoding="utf-8") as f:
                json_data = json.load(f)

            raw_text = json_data.get("body_text", "")
            if not raw_text.strip():
                print(f"[SKIP] Empty data core: {file_path.name}")
                continue

            article_id = json_data.get("article_id", file_path.stem)
            headline   = json_data.get("headline", "")

            # Execute context processing run
            features = process_text(raw_text, file_path.name, folder_label, article_id, headline)
            results.append(features)
            processed_count += 1

        except json.JSONDecodeError:
            print(f"[ERROR] Corrupted JSON matrix skipped: {file_path.name}")
        except Exception as e:
            print(f"[ERROR] Failed feature evaluation on {file_path.name}: {e}")

# ------------
# Output Export & Evaluation Summary

if results:
    df = pd.DataFrame(results)

    timestamp   = datetime.now().strftime("%Y%m%d_%H%M%S")
    output_path = results_path / f"discourse_features_{timestamp}.csv"
    df.to_csv(output_path, index=False, encoding="utf-8-sig")

    print(f"\n--- Feature Processing Generation Run Complete ---")
    print(f"Total Aligned Output Vectors : {len(df)}")
    print(f"Human Rows: {(df['label']=='human').sum()} | AI Rows: {(df['label']=='ai').sum()}")
    print(f"Output Matrix Safely Saved To -> {output_path}")

    print("\n--- Empirical Mean Variations Across Sub-Corpora ---")
    summary_cols = [
        "hedge_per_1k", "existential_hedge_per_1k", "booster_per_1k", 
        "attribution_per_1k", "passive_per_1k", "entity_per_1k",
    ]
    print(df.groupby("label")[summary_cols].mean().round(3).to_string())
else:
    print("[ERROR] No features extracted. Check raw input directories.")